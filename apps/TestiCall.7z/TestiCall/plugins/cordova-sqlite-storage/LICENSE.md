# Licenses

## Common Javascript

MIT or Apache 2.0

## Android version

MIT or Apache 2.0

## iOS/macOS version

MIT only

## Windows version

MIT or Apache 2.0

### SQLite3-WinRT

by @doo (doo GmbH)

MIT License
